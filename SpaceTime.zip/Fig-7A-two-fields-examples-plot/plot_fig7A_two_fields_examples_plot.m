%%

clear;clc;close    

load([pwd,'\two_fields_speed_time_pred_map_example\'...
    'M284_motor_worldA_day26_two_field_pred_map.mat']);

%% plot
n=length(lapfield_s);
m=ceil(sqrt(n));

space_bins=1.5:3:150;
time_bins=0.1:0.2:10;

%%
k=1;         % �ܸ�����cell_field_2�ĳ���

figure(1);

lap_num=size(lapfield_s{k},1);

subplot(2,3,1);
h=imagesc(space_bins,[],lapfield_s{k});axis xy;box off;axis square;
set(h,'alphadata',~isnan(lapfield_s{k}));
xlabel('Position (cm)');title(num2str(cell_field_2(k)));

subplot(2,3,2);
h=imagesc(time_bins,[],lapfield_t{k});axis xy;box off;axis square;
set(h,'alphadata',~isnan(lapfield_t{k}));
xlabel('Time (s)');

subplot(2,3,4);
plot(space_bins,raw_s_field{k},'color',[0.5,0.5,0.5]);hold on;
plot(space_bins,raw_s_field2{k,1},'r');hold on;
plot(space_bins,raw_s_field2{k,2},'g');
box off;axis square;axis([0 150 0 inf]);
xlabel('Position (cm)');ylabel('Response');

subplot(2,3,5);
plot(time_bins,pred_t_field{k,1},'r');hold on;
plot(time_bins,pred_t_field{k,2},'g');
box off;axis square;axis([0 10 0 inf]);
xlabel('time (s)');ylabel('Response');
title([' r = ',num2str(corr(pred_t_field{k,1}',pred_t_field{k,2}'))]);

%%




