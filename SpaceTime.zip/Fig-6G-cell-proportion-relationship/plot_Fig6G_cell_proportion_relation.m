%%

clear;clc;close

%%  Fig.6G

prop_path=[pwd,'\cell_proportion_selected\'];

prop_name={
    'cell_proportion_volun.mat';
    'cell_proportion_motor_speed.mat';
    'cell_proportion_motor_ring.mat';
    'cell_proportion_motor_time.mat';
    'cell_proportion_motor_distance.mat';
    };
Paradigm_names={'Voluntary';'Motor-speed';'Motor-ring';'Motor-time';'Motor-distance'};

% colors���������R G Bģʽ����
% colors=color_npg([1,3,4,5,6],:);
colors=[[0,1,0];[1,0,0];[0,0,0];[0,0,1];[1,0,1]];

paradigm_num=length(prop_name);

%%

data=cell(paradigm_num);
 
for i=1:paradigm_num
    data{i,1}=load([prop_path,prop_name{i}]);
end

%
cell_num_thr=50;  %��ĸ������50

%
cell_prop_s=[];cell_prop_t_tilt=[];
cell_prop_t=[];cell_prop_s_tilt=[];

for i=1:paradigm_num
    sess_idx=data{i}.Cell_num_s(:,2)>=cell_num_thr & data{i}.Cell_num_t(:,4)>=cell_num_thr;
    cell_prop_s=[cell_prop_s;data{i}.Cell_prop_s(sess_idx)];
    cell_prop_t_tilt=[cell_prop_t_tilt;data{i}.Cell_prop_t_tilt(sess_idx)];
    
    sess_idx=data{i}.Cell_num_t(:,2)>=cell_num_thr & data{i}.Cell_num_s(:,4)>=cell_num_thr;
    cell_prop_t=[cell_prop_t;data{i}.Cell_prop_t(sess_idx)];
    cell_prop_s_tilt=[cell_prop_s_tilt;data{i}.Cell_prop_s_tilt(sess_idx)];    
end

[r1,p1]=corr(cell_prop_t,cell_prop_s_tilt);
[r2,p2]=corr(cell_prop_s,cell_prop_t_tilt);

%% ��б��������һ��ά��cell�����������

figure(1);

subplot(1,2,1);

for i=1:paradigm_num
    sess_idx=data{i}.Cell_num_t(:,1)>=cell_num_thr & data{i}.Cell_num_s(:,4)>=cell_num_thr;
    plot(data{i}.Cell_prop_t(sess_idx),data{i}.Cell_prop_s_tilt(sess_idx),'.','color',colors(i,:));
    hold on;
end
box off;axis square;axis([0 1 0 1]);
xlabel('time cell proportion');
ylabel('space tilt cell proportion');
text(0.6,0.3,['r = ',num2str(r1)]);text(0.6,0.2,['p = ',num2str(p1)]);

subplot(1,2,2);

for i=1:paradigm_num
    sess_idx=data{i}.Cell_num_s(:,1)>=cell_num_thr & data{i}.Cell_num_t(:,4)>=cell_num_thr;
    plot(data{i}.Cell_prop_s(sess_idx),data{i}.Cell_prop_t_tilt(sess_idx),'.','color',colors(i,:));
    hold on;
    
    % ��ע��ͬ��ɫ�����������
    plot(0.05,1-0.07*i,'.','color',colors(i,:));text(0.08,1-0.07*i,Paradigm_names{i});
    
end
box off;axis square;axis([0 1 0 1]);
xlabel('space cell proportion');
ylabel('time tilt cell proportion');
text(0.6,0.3,['r = ',num2str(r2)]);text(0.6,0.2,['p = ',num2str(p2)]);

%%








%%






%%





