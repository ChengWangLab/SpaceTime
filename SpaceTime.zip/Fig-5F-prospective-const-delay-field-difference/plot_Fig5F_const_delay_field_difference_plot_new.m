%%

clear;clc;close

%%
Delay_path=[pwd,'\constant_delay_field_difference_merge\'];
Delay_name={
    'Delay_volun.mat';
    'Delay_motor_speed.mat';
    'Delay_motor_ring.mat';
    'Delay_motor_time.mat';
    'Delay_motor_distance.mat';
    };

n=length(Delay_name);
Titles={'Voluntary';'Motor-VR';'Bottomless-Car';'Motor-time';'Motor-distance'};
Colors={'g';'r';'k';'b';'m'};

%% ǰ2/3�ٶȵ�slope<0��Slope>0�ֿ���
data=cell(n,1);

for i=1:n
    
    data{i}=load([Delay_path,Delay_name{i}]);        
    data{i}.Delay_s_mean=nanmean(data{i}.Delay_s,2);
    data{i}.Delay_s_mean_positive=data{i}.Delay_s_mean(data{i}.P_value_s<0.05&data{i}.Slope_s>0);
    data{i}.Delay_s_mean_negative=data{i}.Delay_s_mean(data{i}.P_value_s<0.05&data{i}.Slope_s<0);
    data{i}.md_s_positive=nanmedian(data{i}.Delay_s_mean_positive); % median
    data{i}.p_s_positive=signrank(data{i}.Delay_s_mean_positive,0); % p
    data{i}.md_s_negative=nanmedian(data{i}.Delay_s_mean_negative); % median
    data{i}.p_s_negative=signrank(data{i}.Delay_s_mean_negative,0); % p
    
    data{i}.Delay_t_mean=nanmean(data{i}.Delay_t,2);
    data{i}.Delay_t_mean_negative=data{i}.Delay_t_mean(data{i}.P_value_t<0.05&data{i}.Slope_t<0);
    data{i}.Delay_t_mean_positive=data{i}.Delay_t_mean(data{i}.P_value_t<0.05&data{i}.Slope_t>0);   
    data{i}.md_t_negative=nanmedian(data{i}.Delay_t_mean_negative);
    data{i}.p_t_negative=signrank(data{i}.Delay_t_mean_negative,0);
    data{i}.md_t_positive=nanmedian(data{i}.Delay_t_mean_positive);
    data{i}.p_t_positive=signrank(data{i}.Delay_t_mean_positive,0);
end

%% Fig.5F-new Correlation
f=figure(1); 

subplot(1,3,1); % space tilt
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-50:1:50;
for i=1:n
    k=histc(data{i}.Delay_s_mean_negative,data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
lenx=5;%�Ӹ�bar
for i=1:n
x0=5;y0=0.6-0.1*i;plot([x0,x0+lenx],[y0,y0],'color',Colors{i});text(x0+lenx+0.1,y0+0.01,Titles{i});
end
xlabel({'Space difference (cm)';'(Observed - predicted)'});ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-40:20:40);set(gca,'Ytick',[0,0.5,1]);axis([-40 40 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);

subplot(1,3,2); %
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-5:0.1:5;
for i=1:n
    k=histc(data{i}.Delay_t_mean_positive,data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
xlabel({'Time difference (s)';'(Observed - predicted)'});ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-2:1:2);set(gca,'Ytick',[0,0.5,1]);axis([-2 2 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);

set(f,'Position',[383.0000 457 990 493]);

%% 



%%