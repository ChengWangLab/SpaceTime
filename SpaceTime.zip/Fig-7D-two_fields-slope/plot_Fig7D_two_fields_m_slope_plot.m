%%

clear;clc;close

load('ancova_COMs_motor_speed.mat');

%% Fig7D two slope������ͬ��cell������Shuffle�Ƚ�
f=figure(1);

p1_COM=sum(Ancova_test_COMs_1.proportion_shuff>Ancova_test_COMs_1.proportion)/1000;

subplot(2,3,1);
histogram(Ancova_test_COMs_1.proportion_shuff,0.4:0.01:0.65,'facecolor',[0.5,0.5,0.5]);box off;axis square;
hold on;plot([Ancova_test_COMs_1.proportion,Ancova_test_COMs_1.proportion],[0,150],'r');
title(['p = ',num2str(p1_COM)]);
xlabel('Proportion');ylabel('Shuffling number');

set(f,'Position',[568 263 879 555]);

%%






%%




