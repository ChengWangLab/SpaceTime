function corr_maps=get_corr_two_maps(map_s1,map_s2)

% ����map������û��normalized��
% map_s1=map_s1./max(map_s1,[],2);
% map_s2=map_s2./max(map_s2,[],2);

[~,m]=size(map_s1);
[~,n]=size(map_s2);

corr_maps=corrcoef([map_s1,map_s2],'Rows','pairwise');
corr_maps=corr_maps(1:m,m+1:m+n);

% corr_maps=zeros(m,n)*nan;
% for i=1:m
%     for j=1:n
%          corrs=corrcoef(map_s1(:,i),map_s2(:,j));  
%          corr_maps(i,j)=corrs(1,2);
%     end
% end
% 
% corr_maps=corrcoef([map_s1(:,[m,1:m-1]),map_s2(:,[n,1:n-1])],'Rows','pairwise');
% corr_maps=corr_maps(1:m,m+1:m+n);





