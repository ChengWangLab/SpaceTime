%%

clear;clc;close

%% 
% active in at least one world
load('Fig2ABC-correlation-motor-B-motor-A-active-cells.mat');
% load('Fig2DEF-correlation-motor-speed-motor-time-active-cells.mat');

%% correlation��p��median

load('color_npg.mat');

[p_corr_s1_pair_st,h,stats]=signrank(corr_s_s1_pair,corr_t_s1_pair);
med_corr=[nanmedian(corr_s_s1_pair),nanmedian(corr_t_s1_pair)];

stat_corr=[prctile(corr_s_s1_pair,25),prctile(corr_t_s1_pair,25);
    prctile(corr_s_s1_pair,50),prctile(corr_t_s1_pair,50);
    prctile(corr_s_s1_pair,75),prctile(corr_t_s1_pair,75)];

%% plot together

f=figure(1);

set(f,'Position',[680 350 710 630]);

cell_num=size(map_s_s11,1);
subplot(3,3,1);
imagesc(space_bins,[],map_s_s11);title(Sess_tags{1});caxis([0 1]);colormap(jet);xlabel('Space (cm)');box off;axis square;
set(gca,'ytick',[1,cell_num]);ylabel('Active cells');
subplot(3,3,2);
imagesc(space_bins,[],map_s_s12);title(Sess_tags{2});caxis([0 1]);colormap(jet);box off;axis square;xlabel('Space (cm)');
set(gca,'ytick',[1,cell_num]);

cell_num=size(map_t_s11,1);
subplot(3,3,4);
imagesc(time_bins,[],map_t_s11);title(Sess_tags{1});caxis([0 1]);colormap(jet);
xlabel('Time (s)');box off;axis square;set(gca,'ytick',[1,cell_num]);ylabel('Active cells');
subplot(3,3,5);
imagesc(time_bins,[],map_t_s12);title(Sess_tags{2});caxis([0 1]);colormap(jet);box off;axis square;xlabel('Time (s)');
set(gca,'ytick',[1,cell_num]);

% cumsum
color_s=color_npg(1,:);
color_t=color_npg(3,:);

subplot(3,3,[3,6]);
data_bins=-1:0.05:1;
k1=histc(corr_s_s1_pair,data_bins);
k2=histc(corr_t_s1_pair,data_bins);

k11=cumsum(k1)/sum(k1);k22=cumsum(k2)/sum(k2);
k11=[0;k11(1:end-1)];k22=[0;k22(1:end-1)];
plot(data_bins,k11,'color',color_s);hold on;plot(data_bins,k22,'color',color_t);
xlabel('Correlation');ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-1:1:1);set(gca,'Ytick',[0,0.5,1]);axis([-1 1 0 1]);set(gca,'tickdir','out','ticklength',[0.05,0.05]);

lenx=0.2;%�Ӹ�bar
x0=-0.9;y0=0.9;plot([x0,x0+lenx],[y0,y0],'color',color_s);text(x0+lenx+0.1,y0+0.01,['Space  median=',num2str(med_corr(1))]);
x0=-0.9;y0=0.8;plot([x0,x0+lenx],[y0,y0],'color',color_t);text(x0+lenx+0.1,y0+0.01,['Time    median=',num2str(med_corr(2))]);

text(0.5,0.5,['p-st=',num2str(p_corr_s1_pair_st)]);

%%
corr_s_s1=get_corr_two_maps(map_s_s11,map_s_s12);
corr_t_s1=get_corr_two_maps(map_t_s11,map_t_s12);

%% plot together

f=figure(3);

set(f,'Position',[680 350 710 630]);

cell_num=size(map_s_s11,1);
subplot(3,3,1);
imagesc(space_bins,[],map_s_s11);title(Sess_tags{1});caxis([0 1]);colormap(jet);xlabel('Space (cm)');box off;%axis square;
set(gca,'ytick',[1,cell_num]);ylabel('Sorted space cells');
subplot(3,3,2);
imagesc(space_bins,[],map_s_s12);title(Sess_tags{2});caxis([0 1]);colormap(jet);box off;axis square;
xlabel('Space (cm)');set(gca,'ytick',[1,cell_num]);
subplot(3,3,3);
imagesc(space_bins,space_bins,corr_s_s1);colormap(jet);axis xy;caxis([0 0.5]);
xlabel(Sess_tags{2});ylabel(Sess_tags{1});box off;axis square;

cell_num=size(map_t_s11,1);
subplot(3,3,4);
imagesc(time_bins,[],map_t_s11);title(Sess_tags{1});caxis([0 1]);colormap(jet);
xlabel('Time (s)');box off;axis square;set(gca,'ytick',[1,cell_num]);ylabel('Sorted time cells');
subplot(3,3,5);
imagesc(time_bins,[],map_t_s12);title(Sess_tags{2});caxis([0 1]);colormap(jet);box off;axis square;xlabel('Time (s)');
set(gca,'ytick',[1,cell_num]);
subplot(3,3,6);
imagesc(time_bins,time_bins,corr_t_s1);axis xy;caxis([0 0.5]);colormap(jet);
xlabel(Sess_tags{2});ylabel(Sess_tags{1});box off;axis square;

%%