%%

clear;clc;close

%%
Info_path=[pwd,'\Flip_velt_test6_info\'];

Info_name={
    'Flip_velt_info_volun.mat';
    'Flip_velt_info_motor_speed.mat';
    'Flip_velt_info_motor_ring.mat';
    'Flip_velt_info_motor_time.mat';
    'Flip_velt_info_motor_distance.mat';
    };

n=length(Info_name);

xlabels={'Voluntary';'Motor-VR';'Bottomless-Car';'Motor-time';'Motor-distance'};
Titles={'Voluntary';'Motor-VR';'Bottomless-Car';'Motor-time';'Motor-distance'};
Colors={'g';'r';'k';'b';'m'};

%%
for i=1:n
    data{i,1}=load([Info_path,Info_name{i}]);
end

%% Fig.3E Correlation

f=figure(1); 

subplot(2,5,1); % 
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-4:0.05:4;
for i=1:n
    k=histc(data{i}.SI_s_m-data{i}.SI_s_velt_m,data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
xlabel({'Delta info. of space map';'Observed - Independent'});ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-2:1:2);set(gca,'Ytick',[0,0.5,1]);axis([-2 2 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);title('Independent model for space map');

subplot(2,5,2); % 
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-4:0.05:4;
for i=1:n
    k=histc(data{i}.SI_t_m-data{i}.SI_t_velt_m,data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
xlabel({'Delta info. of time map';'Observed - Independent'});ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-2:1:2);set(gca,'Ytick',[0,0.5,1]);axis([-2 2 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);title('Independent model for time map');

subplot(2,5,3); % 
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-4:0.05:4;
for i=1:n
    ks=data{i}.SI_s_flip_m>0;
    k=histc(data{i}.SI_s_m(ks)-data{i}.SI_s_flip_m(ks),data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
xlabel({'Delta info. of space map';'Observed - Mirrored'});ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-2:1:2);set(gca,'Ytick',[0,0.5,1]);axis([-2 2 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);title('Mirrored model for space map');

subplot(2,5,4); % space tilt predicted t info
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-4:0.05:4;
for i=1:n
    kt=data{i}.SI_t_flip_m>0;
    k=histc(data{i}.SI_t_m(kt)-data{i}.SI_t_flip_m(kt),data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
xlabel({'Delta info. of time map';'Observed -  Mirrored'});ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-2:1:2);set(gca,'Ytick',[0,0.5,1]);axis([-2 2 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);title('Mirrored model for time map');

subplot(2,5,5);
lenx=0.5;hold on;%�Ӹ�bar
for i=1:n
x0=-1.8;y0=1-0.1*i;plot([x0,x0+lenx],[y0,y0],'color',Colors{i});text(x0+lenx+0.1,y0+0.01,Titles{i});
end
axis([-2 2 0.3 1]);axis off;

subplot(2,5,6); % space velt predicted t info
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-4:0.05:4;
for i=1:n
    k=histc(data{i}.SI_pred_t_m-data{i}.SI_pred_t_velt_m,data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
xlabel({'Delta info. of time map';'Observed - Predicted'});ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-2:1:2);set(gca,'Ytick',[0,0.5,1]);axis([-2 2 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);

subplot(2,5,7); % 
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-4:0.05:4;
for i=1:n
    k=histc(data{i}.SI_pred_s_m-data{i}.SI_pred_s_velt_m,data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
xlabel({'Delta info. of space map';'Observed - Predicted'});ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-2:1:2);set(gca,'Ytick',[0,0.5,1]);axis([-2 2 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);

subplot(2,5,8); % space tilt predicted t info
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-4:0.05:4;
for i=1:n
    ks=data{i}.SI_s_flip_m>0;
    k=histc(data{i}.SI_pred_t_m(ks)-data{i}.SI_pred_t_flip_m(ks),data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
xlabel({'Delta info. of time map';'Observed - Predicted'});ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-2:1:2);set(gca,'Ytick',[0,0.5,1]);axis([-2 2 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);

subplot(2,5,9); % 
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-4:0.05:4;
for i=1:n
    kt=data{i}.SI_t_flip_m>0;
    k=histc(data{i}.SI_pred_s_m(kt)-data{i}.SI_pred_s_flip_m(kt),data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
xlabel({'Delta info. of space map';'Observed - Predicted'});ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-2:1:2);set(gca,'Ytick',[0,0.5,1]);axis([-2 2 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);

set(f,'Position',[383 300 1300 560]);

%%











%%















%%





