%%

clear;clc;close

load('color_npg.mat');

%%
Slope_path=[pwd,'\Correlation_slope\'];
Slope_name={
    'Correlation_slope_volun.mat';
    'Correlation_slope_motor_speed.mat';
    'Correlation_slope_motor_ring.mat';
    'Correlation_slope_motor_time.mat';
    'Correlation_slope_motor_distance.mat';
    };

n=length(Slope_name);

xlabels={'Voluntary';'Motor-VR';'Bottomless-Car';'Motor-time';'Constant-duration'};
Titles={'Voluntary';'Motor-speed';'Motor-ring';'Motor-time';'Constant-duration'};
Colors={'g';'r';'k';'b';'m'};

%%
for i=1:n
    data{i,1}=load([Slope_path,Slope_name{i}]);
    
    data{i,1}.Cell_s=sum(data{i}.Cell_num_space_tilt);
    data{i,1}.Cell_t=sum(data{i}.Cell_num_time_tilt);
    
    data{i,1}.correlation_s=cell2mat(data{i}.Correlation_s);
    data{i,1}.slope_s=cell2mat(data{i}.Slope_s);
    data{i,1}.correlation_t=cell2mat(data{i}.Correlation_t);
    data{i,1}.slope_t=cell2mat(data{i}.Slope_t);

    
    Space_tilt_proportion(i)=data{i}.Cell_s(3)/data{i}.Cell_s(1);
    Time_tilt_proportion(i)=data{i}.Cell_t(3)/data{i}.Cell_t(1);
end

%% Fig 4F Correlation
f=figure(1); 

subplot(1,3,1); % space tilt
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-1:0.05:1;
for i=1:n
    k=histc(data{i}.correlation_s,data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
lenx=0.2;%�Ӹ�bar
for i=1:n
x0=-0.8;y0=1-0.1*i;plot([x0,x0+lenx],[y0,y0],'color',Colors{i});text(x0+lenx+0.1,y0+0.01,Titles{i});
end
xlabel('Space-duration correlation');ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-1:0.5:1);set(gca,'Ytick',[0,0.5,1]);axis([-1 1 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);

subplot(1,3,2); %
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-1:0.05:1;
for i=1:n
    k=histc(data{i}.correlation_t,data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
% lenx=0.01;%�Ӹ�bar
% for i=1:n
% x0=-0.04;y0=1-0.1*i;plot([x0,x0+lenx],[y0,y0],'color',Colors{i});text(x0+lenx+0.005,y0+0.01,Titles{i});
% end
xlabel('Time-distance correlation');ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-1:0.5:1);set(gca,'Ytick',[0,0.5,1]);axis([-1 1 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);

set(f,'Position',[383.0000 457 990 493]);

%%  Fig.S3F
f=figure(3); 

subplot(1,3,1); % space tilt
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-10:0.5:10;
for i=1:n
    k=histc(data{i}.slope_s,data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
lenx=1;%�Ӹ�bar
for i=1:n
x0=-4;y0=1-0.1*i;plot([x0,x0+lenx],[y0,y0],'color',Colors{i});text(x0+lenx+0.1,y0+0.01,Titles{i});
end
xlabel('Space-duration slope');ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-10:5:10);set(gca,'Ytick',[0,0.5,1]);axis([-5 5 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);

subplot(1,3,2); %
plot([0,0],[0,1],'--','color',[0.5,0.5,0.5]);hold on;
data_bins=-0.1:0.005:0.1;
for i=1:n
    k=histc(data{i}.slope_t,data_bins);kk=cumsum(k)/sum(k);kk=[0;kk(1:end-1)];
    plot(data_bins,kk,'color',Colors{i});
end
% lenx=0.01;%�Ӹ�bar
% for i=1:n
% x0=-0.04;y0=1-0.1*i;plot([x0,x0+lenx],[y0,y0],'color',Colors{i});text(x0+lenx+0.005,y0+0.01,Titles{i});
% end
xlabel('Time-distance slope');ylabel('Cumulative probability');box off;axis square;
set(gca,'Xtick',-0.05:0.05:0.05);set(gca,'Ytick',[0,0.5,1]);axis([-0.05 0.05 0 1]);
set(gca,'tickdir','out','ticklength',[0.05,0.05]);

set(f,'Position',[383.0000 457 990 493]);

%%











%%















%%





