%%

clear;clc;close

load('color_npg.mat');

%% 3 paradigms
load([pwd,'\Data-KStest-KLD\KS-KLD-Voluntary-VR.mat']);
% load([pwd,'\Data-KStest-KLD\KS-KLD-Motorized-VR.mat']);
% load([pwd,'\Data-KStest-KLD\KS-KLD-Bottomless-Car.mat']);

%% plot 
X_bins=0.01:0.02:1;

% color1=color_npg(1,:);color2=color_npg(3,:);
color1='r';color2='b';

subplot(2,3,1);
histogram(X1,0:0.02:1,'Normalization','probability','FaceColor',color1,'EdgeColor','None');box off;axis square;
axis([0 1 0 0.04]);xlabel('Space peak (Norm.)');ylabel('Proportion');
subplot(2,3,2);
histogram(X2,0:0.02:1,'Normalization','probability','FaceColor',color2,'EdgeColor','None');box off;axis square;
axis([0 1 0 0.06]);xlabel('Time peak (Norm.)');ylabel('Proportion');
subplot(2,3,3);
plot(X_bins,cdf_X1,'color',color1);hold on;plot(X_bins,cdf_X2,'color',color2);
lenx=0.2;%�Ӹ�bar
x0=0.1;y0=0.95;plot([x0,x0+lenx],[y0,y0],'color',color1);text(x0+lenx+0.1,y0+0.01,'Space');
x0=0.1;y0=0.85;plot([x0,x0+lenx],[y0,y0],'color',color2);text(x0+lenx+0.1,y0+0.01,'Time');
text(0.5,0.3,['p = ',num2str(p_KS)]);
set(gca,'Xtick',0:0.5:1);set(gca,'Ytick',[0,0.5,1]);set(gca,'tickdir','out','ticklength',[0.05,0.05]);
box off;axis square;axis([0 1 0 1]);xlabel('Field peak (Norm.)');ylabel('Cumulative probability');

subplot(2,3,4:6);
histogram(kld_X12_shuff,0:0.002:0.3,'Normalization','probability','facecolor',[0.5,0.5,0.5]);box off;
hold on;plot([kld_X12,kld_X12],[0,0.09],'r');
text(kld_X12,0.11,'Observed');text(kld_X12,0.10,'p < 0.001');
% axis([0 0.18 0 0.12]);set(gca,'xtick',0:0.06:0.18,'ytick',0:0.03:0.12);
xlabel('KLD');ylabel('Proportion');

%%


