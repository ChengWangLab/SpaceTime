%%

clear;clc;close

%%
Slope_path=[pwd,'\Correlation_slope_st\'];
Slope_name={
    'Correlation_slope_st_volun.mat';
    'Correlation_slope_st_motor_speed.mat';
    'Correlation_slope_st_motor_ring.mat';
    'Correlation_slope_st_motor_time.mat';
    'Correlation_slope_st_motor_distance.mat';

    };

n=length(Slope_name);

Titles={'Voluntary';'Motor-speed';'Motor-ring';'Motor-time';'Motor-distance'};
Colors={'g';'r';'k';'b';'m'};

%%
for i=1:n
    data{i,1}=load([Slope_path,Slope_name{i}]);
    
   data{i}.Cell_st=sum(data{i}.Cell_num_spacetime_tilt);  % active both-field both-tilt
    
   data{i}.correlation_s=cell2mat(data{i}.Correlation_s_st_tilt);
   data{i}.slope_s=cell2mat(data{i}.Slope_s_st_tilt);
   data{i}.correlation_t=cell2mat(data{i}.Correlation_t_st_tilt);
   data{i}.slope_t=cell2mat(data{i}.Slope_t_st_tilt);  
     
   ST_tilt_proportion(i,1)=data{i}.Cell_st(3)/data{i}.Cell_st(2);
end

%% Correlation
figure(1)

for i=1:n   
    subplot(1,n,i);
    plot(data{i}.correlation_s,data{i}.correlation_t,'.','color',Colors{i});hold on;
    plot([-1 1],[0 0],'--','color',[0.5,0.5,0.5]);
    plot([0 0],[-1 1],'--','color',[0.5,0.5,0.5]);
    box off;axis square;axis([-1 1 -1 1]);
    xlabel('Space-Duration correlation');
    ylabel('Time-distance correlation');
    title(Titles{i});
    
end

%% Slope
figure(2)

for i=1:n
    
    subplot(1,n,i);
    plot(data{i}.slope_s,data{i}.slope_t,'.','color',Colors{i});hold on;
    plot([-5 5],[0 0],'--','color',[0.5,0.5,0.5]);
    plot([0 0],[-0.05 0.05],'--','color',[0.5,0.5,0.5]);
    box off;axis square;axis([-5 5 -0.05 0.05]);
    xlabel('Space-Duration slope');
    ylabel('Time-distance slope');
    title(Titles{i});
end

%%











%%















%%





